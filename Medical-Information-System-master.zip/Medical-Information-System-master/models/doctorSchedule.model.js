const moment = require('moment');
const mongoose = require('mongoose');
var Schema = mongoose.Schema;

const doctorScheduleSchema = new Schema({
    doctor: {
        type: Schema.Types.ObjectId,
        unique: true,
        ref: 'Doctor'
    },
    availableDays: {
        type: [String],
        enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    timeSlots: [{
        startTime: {
            type: Date
        },
        endTime: {
            type: Date
        }
    }],
    slotSpan: {
        type: Number,
        enum: [15, 30]
    }
},
    { timestamps: true }
);

//Export Schema here...
const DoctorSchedule = mongoose.model('DoctorSchedule', doctorScheduleSchema);

module.exports = DoctorSchedule;

module.exports.getAvailableDaysData = async function (doctorId) {
    try {
        let doctorSchedule = await DoctorSchedule.findOne({ doctor: doctorId }).exec();

        if (doctorSchedule) {
            return ({
                Error: false,
                Message: 'Schedule of Specific Doctor.',
                Data: doctorSchedule
            });
        }
        else {
            return ({
                Error: true,
                Message: 'No Schedule Found.',
                Data: {}
            });
        }

    }
    catch (e) {
        console.log("Error in Model: ", e);
        return ({
            Error: true,
            Message: 'No Schedule Found',
            Data: {}
        });
    }
};

// ADD DOCTOR SCHEDULE
module.exports.insertDoctorScheduleData = async function (doctorScheduleData) {
    let doctorSchedule;
    try {
        doctorSchedule = await new DoctorSchedule(doctorScheduleData).save();
    }
    catch (err) {
        console.log("Error saving schedule: ", err);
        return ({
            Error: true,
            Message: 'Error Saving Doctor Schedule.',
            Data: {}
        });
    }
    return ({
        Error: false,
        Message: 'Doctor Schedule Saved Successfully.',
        Data: doctorSchedule
    });
};

module.exports.getAvailableSlotsData = async function (doctorId, dayQuery) {
    let availableSlots;
    let slotSpan;
    // let timeSlots;
    try {
        availableSlots = await DoctorSchedule.findOne({ doctor: doctorId }).exec();
    }
    catch (err) {
        return ({
            Error: true,
            Message: 'Error Finding Schedule.',
            Data: {}
        });
    }
    if (availableSlots) {
        let timeStops = [];
        slotSpan = availableSlots.slotSpan;
        for (var i = 0; i < availableSlots.timeSlots.length; i++) {
            let timeStopsArr = getTimeStops(availableSlots.timeSlots[i].startTime, availableSlots.timeSlots[i].endTime, availableSlots.slotSpan);
            timeStops.push(...timeStopsArr);
            // timeStops.push(null);
            // console.log('timeStops ', timeStops);
        }
        console.log('TimeSlots: ', timeStops);
        return ({
            Error: false,
            Message: 'Available Slots DS',
            Data: { timeStops: timeStops, slotSpan: slotSpan }
        });
    }
    else {
        return ({
            Error: true,
            Message: 'No Schedule',
            Data: {}
        });
    }
};

function getTimeStops(start, end, duration) {
    var startTime = moment(start);
    var endTime = moment(end);

    console.log(startTime.format('HH:mm'));
    console.log(endTime.format('HH:mm'));

    if (endTime.isBefore(startTime)) {
        endTime.add(1, 'day');
    }

    var timeStops = [];

    while (startTime <= endTime) {
        timeStops.push(new moment(startTime).format('HH:mm'));
        startTime.add(duration, 'minutes');
    }
    return timeStops;
}