const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const validator = require('validator');
const bcrypt = require('bcryptjs');

const patientSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    middleName: {
        type: String,
        default: null,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Rather Not Say']
    },
    dob: {
        type: Date,
        required: true
    },
    status: {
        type: Boolean,
        default: true // true for active profile
    },
    // add specialty here in ailments...
    ailments: [{
        name: {
            type: String,
        },
        treatmentTaken: {
            type: Boolean,
            default: false
        },
        description: {
            type: String,
            default: null
        },
        sufferingSince: {
            type: Date
        },
        treatments: [{
            treatedBy: {
                type: Schema.Types.ObjectId,
                ref: 'Doctor'
            },
            treatmentNames: {
                type: [String]
            } 
        }]
    }],
    email: {
        type: String,
        unique: true,
        required: true,
        trim: true,
        lowercase: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    password: {
        type: String,
        required: true,
        minlength: 5,
        trim: true,
        select: false,
        validate(value) {
            if (value.toLowerCase().includes('password')) {
                throw new Error('Password cannot contain "password"');
            }
        }
    },
    address: {
        houseNo: {
            type: Number,
            required: true
        },
        street: {
            type: String,
            required: true
        },
        landmark: {
            type: String,
            default: null
        },
        village: {
            type: String,
            default: null
        },
        town: {
            type: String,
            default: null
        },
        city: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true
        },
        country: {
            type: String,
            required: true
        },
        zipcode: {
            type: Number,
            required: true
        }
    },
    contactNum: {
        type: [Number],
        required: true
    },
    // tokens: [{
    //     token: {
    //         type: String,
    //         required: true
    //     }
    // }],
    profilePic: {
        type: String,
        default: null
    },
    createdAt: {
        type: Date,
        default: function () {
            return new Date();
        }
    },
    deletedAt: {
        type: Date,
        default: "",
    },
    updatedAt: {
        type: Date,
        default: function () {
            return new Date();
        }
    }
});

//Get virtual property age...
patientSchema.virtual('age').get(function () {

    const birthdate = new Date(this.dob);
    const nbYearRounded = Math.floor((Date.now() - birthdate.getTime()) / (1000 * 3600 * 24 * 365));
    return nbYearRounded;
});

//Get virtual property fullName...
patientSchema.virtual('fullName').get(function () {

    if (this.middleName === null) {
        return this.firstName + ' ' + this.lastName;
    }
    return this.firstName + ' ' + this.middleName + ' ' + this.lastName;
});

//Set virtual property fullName...
patientSchema.virtual('fullName').set(function (name) {
    let str = name.split(' ');

    if (str.length === 3) {
        this.firstName = str[0];
        this.middleName = str[1];
        this.lastName = str[2];
    }

    this.firstName = str[0];
    this.lastName = str[1];

});

// HASH THE PLAIN TEXT PASSWORD BEFORE SAVING
patientSchema.pre('save', async function (next) {
    const patient = this;

    if (patient.isModified('password')) {
        patient.password = await bcrypt.hash(patient.password, 8);
    }
    next();
});

const Patient = mongoose.model('Patient', patientSchema);

module.exports = Patient;

// INSERT PATIENT DATA
module.exports.insertPatientData = function (patientData) {
    return new Promise((resolve, reject) => {
        new Patient(patientData).save(function (error, data) {
            if (error) {
                // winston.error(chalk.red(error));
                resolve({
                    Error: true,
                    Message: "Error Inserting Document",
                })
            } else {
                let age = data.age;
                let fullName = data.fullName;
                resolve({
                    Error: false,
                    Message: "Success",
                    Data: data === null ? {} : { data, age, fullName }
                })
            }
        });
    });
}

// FIND PATIENT BY CREDENTIALS
module.exports.findByPatientCredentials = async function (query) {
    let patient;
    try {
        patient = await Patient.findOne({ email: query.email }).select('+password');
    }
    catch (e) {
        console.log("Error Patient Model: ", e);
        return ({
            Error: true,
            Message: 'No Such Patient Found.',
            Data: {}
        });
    }
    if (!patient) {
        return ({
            Error: true,
            Message: 'Invalid Email',
            Data: {}
        });
    }
    let isMatch;
    try {
        isMatch = await bcrypt.compare(query.password, patient.password);
    }
    catch (e) {
        console.log("Password Error: ", e);
        return ({
            Error: true,
            Message: 'Password does not match.',
            Data: {}
        });
    }
    // console.log("===", isMatch, patient);
    if (!isMatch) {
        return ({
            Error: true,
            Message: 'Invalid Password',
            Data: {}
        });
    }
    return ({
        Error: false,
        Message: 'Patient Data',
        Data: patient
    });
};

// FIND PATIENT BY ID
module.exports.findPatientById = async function (patientId) {
    try {
        console.log('Here: ');
        let patient = await Patient.findOne({_id: patientId, status: true}).exec();
        if(!patient) {
            return ({
                Error: true,
                Message: 'No such Patient Exists/Deleted Account.',
                Data: {}
            });
        }
        else {
            return ({
                Error: false,
                Message: 'Patient Data',
                Data: patient
            });
        } 
    }
    catch (e) {
        return ({
            Error: true,
            Message: 'Database Error.',
            Data: {}
        });
    }
};