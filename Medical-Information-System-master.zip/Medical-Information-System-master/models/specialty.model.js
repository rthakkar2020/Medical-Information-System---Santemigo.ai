const mongoose = require('mongoose');

let specialtySchema = new mongoose.Schema({
    specialty: {
        type: String,
        unique: true
    }
});

const Specialtie = mongoose.model('Specialtie', specialtySchema);

module.exports = Specialtie;

module.exports.getAllSpecialtiesData = async function () {
    try {
        let specialties = await Specialtie.find({}).exec();
        return ({
            Error: false,
            Message: 'Specialties Data',
            Data: specialties
        });
    }
    catch (e) {
        return ({
            Error: true,
            Message: 'No Records found.',
            Data: {}
        })
    }
};