const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const validator = require('validator');
const bcrypt = require('bcryptjs');

const doctorSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    middleName: {
        type: String,
        default: null,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Rather Not Say']
    },
    dob: {
        type: Date,
        required: true
    },
    status: {
        type: Boolean,
        default: true // true for active profile
    },
    email: {
        type: String,
        unique: true,
        required: true,
        trim: true,
        lowercase: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    password: {
        type: String,
        required: true,
        minlength: 5,
        trim: true,
        select: false,
        validate(value) {
            if (value.toLowerCase().includes('password')) {
                throw new Error('Password cannot contain "password"');
            }
        }
    },
    registrationNum: {
        type: String,
        required: true,
        trim: true,
        unique: true
    },
    qualification: {
        type: String,
        required: true,
        trim: true
    },
    yearQualified: {
        type: Number,
        required: true,
        trim: true
    },
    // user:{ type: Schema.Types.ObjectId, ref: 'User', autopopulate: true },
    specialty: {
        type: Schema.Types.ObjectId,
        ref: 'Specialtie',
    },
    registrationDate: {
        type: Date,
        required: true,
    },
    workingSince: {
        type: Number,
        required: true
    },
    address: {
        houseNo: {
            type: Number,
            required: true
        },
        street: {
            type: String,
            required: true
        },
        landmark: {
            type: String,
            default: null
        },
        village: {
            type: String,
            default: null
        },
        town: {
            type: String,
            default: null
        },
        city: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true
        },
        country: {
            type: String,
            required: true
        },
        zipcode: {
            type: Number,
            required: true
        }
    },
    contactNum: {
        type: [Number],
        required: true
    },
    // tokens: [{
    //     token: {
    //         type: String,
    //         required: true
    //     }
    // }],
    profilePic : {
		type : String,
		default : null
	},
	createdAt: {
		type: Date,
		default: function() {
			return new Date();
		}
	},
	deletedAt: {
		type: Date,
		default: "",
    },
    updatedAt: {
        type: Date,
        default: function() {
			return new Date();
		}
    }
}, { getters: true});

//Get virtual property age...
doctorSchema.virtual('age').get( function() {

    const birthdate = new Date(this.dob);
    const nbYearRounded = Math.floor((Date.now() - birthdate.getTime()) / (1000 * 3600 * 24 * 365));
    return nbYearRounded;
});

//Get virtual property fullName...
doctorSchema.virtual('fullName').get( function() {

    if(this.middleName === null) {
        return this.firstName + ' ' + this.lastName;
    }
    return this.firstName + ' ' + this.middleName + ' ' + this.lastName;
});

//Set virtual property fullName...
doctorSchema.virtual('fullName').set( function(name) {
    let str = name.split(' ');

    if(str.length === 3) {
    this.firstName = str[0];
    this.middleName = str[1];
    this.lastName = str[2];
    }

    this.firstName = str[0];
    this.lastName = str[1];

});

// HASH THE PLAIN TEXT PASSWORD BEFORE SAVING
doctorSchema.pre('save', async function (next) {
    const doctor = this;

    if (doctor.isModified('password')) {
        doctor.password = await bcrypt.hash(doctor.password, 8);
    }
    next();
});

//Export Schema here...
const Doctor = mongoose.model('Doctor', doctorSchema);

module.exports = Doctor;

// FIND DOCTOR BY CREDENTIALS
module.exports.findByDoctorCredentials = async function (query)  {
    let doctor;
    try {
        doctor = await Doctor.findOne({ email: query.email }).select('+password');
    }
    catch (e) {
        console.log("Email Error: ", e);
        return ({
            Error: true,
            Message: 'Invalid Email',
            Data: {}
        });
    }
    if (!doctor) {
        return ({
            Error: true,
            Message: 'Invalid Email',
            Data: {}
        });
    }
    let isMatch;
    try {
        isMatch = await bcrypt.compare(query.password, doctor.password);
    }
    catch (e) {
        console.log("Password Error: ", e);
        return ({
            Error: true,
            Message: 'Password does not match.',
            Data: {}
        });
    }
    if (!isMatch) {
        return ({
            Error: true,
            Message: 'Invalid Password',
            Data: {}
        });
    }
    return ({
        Error: false,
        Message: 'Doctor Data',
        Data: doctor
    });
};

// INSERT DOCTOR DATA
module.exports.insertDoctorData = function(doctorData) {
	return new Promise ((resolve, reject) => {
		new Doctor(doctorData).save(function(error, data) {
			if(error) {
                console.log("Error: ", error);
				resolve({
					Error: true,
					Message: "Error Inserting Document",
				})
			} else {
                let age = data.age;
                let fullName = data.fullName;
				resolve({
					Error: false,
					Message: "Success",
					Data: data === null ? {} : {data, age, fullName}
				})
			}
		});
	});
}

// GET ALL DOCTORS BY SPECIALTY
module.exports.getAllDoctorsBySpecialtyData = async function (specialtyId) {
    try {
        let doctors = await Doctor.find({specialty: specialtyId}).populate('specialty').exec();
        console.log("Doc Model: ", doctors);
        return ({
            Error: false,
            Message: 'Doctors By Specialty',
            Data: doctors
        });
    }
    catch (e) {
        return ({
            Error: true,
            Message: 'No Doctors Found.',
            Data: {}
        });
    }
};

//FIND DOCTOR BY CREDENTIALS
// module.exports.getDoctorByCredentials =  function(query) {
//     console.log("Doctor Model/ get by credentials: ", query['email']);
// 	return new Promise ((resolve, reject) => {
// 			Doctor.findOne({email: query['email']}, function(error, data) {
// 			if(error) {
// 				resolve({
// 					Error: true,
// 					Message: "Unable to fetch the data.",
// 					Data:{}
// 				})
// 			} else {

//                 // function(candidatePassword, cb) {
//                 //     bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
//                 //         if (err) return cb(err);
//                 //         cb(null, isMatch);
//                 //     });
//                 console.log('Data Pass: ', data.password);
//                 console.log('Query Pass: ', query.password);
//                 bcrypt.compare(query.password, this.password, function(error, isMatch) {
//                     if (error) {
//                         resolve({
//                             Error: true,
//                             Message: 'Invalid Password',
//                             Data: {}
//                         })
//                     }
//                     else { 
//                         resolve({
//                             Error: false,
//                             Message:"Doctor Data.",
//                             Data: data,
//                         })
//                     }
//                 });
// 			}
// 		});
// 	});
// }

