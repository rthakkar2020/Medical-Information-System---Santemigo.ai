const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const moment = require('moment');

const appointmentSchema = new Schema({
    specialty: {
        type: Schema.Types.ObjectId,
        ref: 'Specialtie'
    },
    doctor: {
        type: Schema.Types.ObjectId,
        ref: 'Doctor'
    },
    patient: {
        type: Schema.Types.ObjectId,
        ref: 'Patient'
    },
    day: {
        type: Date,
        required: true
    },
    startTime: {
        type: Date,
        required: true
    },
    endTime: {
        type: Date,
        required: true
    },
    reason: {
        type: String
    },
    status: {
        type: Boolean,
        // enum: ['pending', 'confirm', 'cancelled'],
        default: true
        // true - confirm and false - cancelled
    },
    archieve: {
        type: Boolean,
        default: false
    }
},
    { timestamps: true }
);

//Export Schema here...
const Appointment = mongoose.model('Appointment', appointmentSchema);

module.exports = Appointment;

// GET APPOINTMENTS FOR SPECIFIC PATIENT/DOCTOR
module.exports.getAppointmentsById = async function (userId) {
    let appointments;
    try {
        appointments = await Appointment.find({ $or: [{ patient: userId }, { doctor: userId }] }).exec();
    }
    catch (e) {
        console.log("Error: ", e);
        return ({
            Error: true,
            Message: 'Database Error.',
            Data: {}
        });
    }
    return ({
        Error: false,
        Message: 'Appointments for Specific Doctor/Patient.',
        Data: appointments
    });
};

// BOOK AN APPOINTMENT
module.exports.bookAppointmentData = async function (appointmentData) {
    try {
        let data = await new Appointment(appointmentData).save();
        return ({
            Error: false,
            Message: 'Appointment Has Been Booked Successfully.',
            Data: data === null ? {} : data
        });
    }
    catch (e) {
        return ({
            Error: true,
            Message: 'Error Booking Appointment.',
            Data: {}
        });
    }
};

// CANCEL APPOINTMENT BY PATIENT
module.exports.cancelAppointmentData = async function (appointmentId, patientId) {
    console.log('Appoint ID: ' + appointmentId + 'Patient ID: ' + patientId);
    try {
        let appointment = await Appointment.findOne({ _id: appointmentId, patient: patientId }).exec();

        console.log("Appointment Patient: ", appointment);

        let currentDateTime = moment();
        let startDateTime = moment(appointment.startTime);
        let invalid = currentDateTime.isAfter(startDateTime);

        let appointmentStatus = appointment.status;

        if (appointmentStatus == true && invalid == false) {
            let updatedAppointment = await Appointment.findOneAndUpdate({ _id: appointmentId, patient: patientId }, { status: false }, { new: true }).populate('patient').exec();
            return ({
                Error: false,
                Message: 'Appointment has been cancelled.',
                Data: updatedAppointment
            });
        }
        if (appointmentStatus == true && invalid == true) {
            return ({
                Error: false,
                Message: 'Cannot Cancel Old Appointments.',
                Data: appointment
            });
        }
        return ({
            Error: false,
            Message: 'Already Cancelled',
            Data: appointment
        });
    }
    catch (e) {
        return ({
            Error: true,
            Message: 'Error in appointment cancellation',
            Data: {}
        });
    }
};

// CANCEL OR CONFIRM APPOINTMENT BY DOCTOR (ACTS LIKE TOGGLE ACTION)
module.exports.cancelOrConfirmAppointmentData = async function (appointmentId, doctorId) {
    let appointment;
    let obj = {};
    console.log('Appoint ID: ' + appointmentId + 'Doctor ID: ' + doctorId);
    try {
        appointment = await Appointment.findOne({ _id: appointmentId, doctor: doctorId }).exec();
    }
    catch (e) {
        console.log("Database Error: ", e);
        return ({
            Error: true,
            Message: 'No Appointments Found.',
            Data: {}
        });
    }
    if (appointment) {
        // console.log("Appointment Doctor: ", appointment);
        let appointmentStatus = appointment.status;
        let updatedAppointment = {};

        let currentDateTime = moment();
        let startDateTime = moment(appointment.startTime);
        let invalid = currentDateTime.isAfter(startDateTime) ? true : false;

        if (invalid == false) {
            if (appointmentStatus == true) {
                try {
                    updatedAppointment = await Appointment.findOneAndUpdate({ _id: appointmentId, doctor: doctorId }, { status: false }, { new: true }).populate('doctor').exec();
                }
                catch (e) {
                    console.log("Error in Cancellation: ", e);
                    return ({
                        Error: true,
                        Message: 'Error in Cancellation.',
                        Data: {}
                    });
                }
                // if (updatedAppointment) {
                    obj = {
                        Error: false,
                        Message: 'Appointment has been cancelled.',
                        Data: updatedAppointment
                    };
                // }
                
            }
            else {
                try {
                    updatedAppointment = await Appointment.findOneAndUpdate({ _id: appointmentId, doctor: doctorId }, { status: true }, { new: true }).populate('doctor').exec();
                }
                catch (e) {
                    console.log("Error in Confirmation: ", e);
                    return({
                        Error: true,
                        Message: 'Error in Confirmation.',
                        Data: {}
                    });
                }

                // if(updatedAppointment) {
                    obj = {
                        Error: false,
                        Message: 'Appointment has been confirmed.',
                        Data: updatedAppointment
                    };
                // }
                
            }
        }
        else {
            obj = {
                Error: true,
                Message: 'Cannot Cancel/Confirm Old Appointments.',
                Data: {}
            }
        }
        return obj;
    }
    else {
        return ({
            Error: true,
            Message: 'No Appointments Found.',
            Data: {}
        });
    }
};

// GET APPOINTMENTS FOR SPECIFIC DOCTOR DATEWISE
module.exports.getAppointments = async function (doctorId, date) {
    let appointments;
    try {
        appointments = await Appointment.find({ doctor: doctorId, day: new Date(date) }).exec();
    }
    catch (err) {
        console.log('Catch here: ');
        return ({
            Error: true,
            Message: 'Error Finding Appointments.'
        });
    }
    console.log('apppp: ', appointments);
    if (appointments) {
        if (appointments.length != 0) {
            return ({
                Error: false,
                Message: 'Appointments for Specific Doctor And Date',
                Data: appointments
            });
        }
        else {
            console.log('Else Here: ');
            return ({
                Error: true,
                Message: 'Error Finding Appointments.',
                Data: {}
            });
        }
    }
}