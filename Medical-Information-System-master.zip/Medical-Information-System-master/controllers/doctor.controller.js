const winston = require('winston');
const chalk = require('chalk');

//MODELS
const doctorModel = require('../models/doctor.model');
const appointmentModel = require('../models/appointment.model');
const DoctorScheduleModel = require('../models/doctorSchedule.model');

//MIDDLEWARES
const authMiddleware = require('../middleware/auth');

// CREATE DOCTOR
module.exports.insertDoctor = async function (req, res) {
	let doctor;
	try {
		doctor = await doctorModel.insertDoctorData(req.body);
	}
	catch (e) {
		console.log("error: ", err);
	}
	res.json(doctor);
}

// DOCTOR LOGIN
exports.login = async function (req, res) {
	let getDoctor;
	try {
		getDoctor = await doctorModel.findByDoctorCredentials({
			email: req.body.email,
			password: req.body.password
		});
	}
	catch (e) {
		console.log("Error: ", e);
	}
	if (getDoctor) {
		// console.log('Doctor Controller/ Login: ', getDoctor);
		let length = Object.keys(getDoctor.Data).length;
		if (length == 0) {
			return res.json({
				Error: true,
				Message: "Wrong username and/or password.",
			})
		}
		else {
			let token;
			try {
				token = await authMiddleware.generateAuthToken(
					JSON.parse(JSON.stringify(getDoctor))
				);
			}
			catch (e) {
				console.log("Token Error: ", e);
			}
			res.json({
				Error: false,
				Message: "Login successful",
				Data: {
					token: token
				}
			});
		}
	}
}

// GET ALL APPOINTMENTS OF SPECIFIC DOCTOR
module.exports.getAppointments = async function (req, res) {
	let getAppointments = await appointmentModel.getAppointmentsByDoctorId(req.user._id);

	console.log('Doctor Controller/ Appointments: ', getAppointments);

	let length = Object.keys(getAppointments.Data).length;
	if (length == 0) {
		return res.json({
			Error: true,
			Message: "No Appointments Found.",
		});
	}

	res.json({
		Error: false,
		Message: 'Appointments for Specific Doctor',
		Data: getAppointments.Data
	});
};

// CANCEL OR CONFIRM APPOINTMENT
module.exports.cancelOrConfirmAppointment = async function (req, res) {
	// console.log("Confirm/Cancel: ", req.user);
	let cancelAppointment;
	try {
		cancelAppointment = await appointmentModel.cancelOrConfirmAppointmentData(req.params.appointmentId, req.user._id);
	}
	catch (e) {
		console.log("Error: ", e);
	}
	if (cancelAppointment) {
		// console.log('Doctor Controller: / Appointments/ CancelOrConfirm ', cancelAppointment);

		let length = Object.keys(cancelAppointment.Data).length;
		if (length === 0) {
			delete cancelAppointment.Data;
			return res.json(cancelAppointment);
		}
		res.json(cancelAppointment);
	}
};

// DOCTOR LOGOUT
exports.logout = function (req, res) {
	req.session.destroy();
	res.json({
		Error: false,
		Message: "Logout Successfully",
	})
};

// ADD DOCTOR SCHEDULE
module.exports.insertDoctorSchedule = async function (req, res) {
	let insertDoctorSchedule;
	req.body.doctor = req.user._id;
	try {
		insertDoctorSchedule = await DoctorScheduleModel.insertDoctorScheduleData(req.body);
		let length = Object.keys(insertDoctorSchedule).length;
		if (length == 0) {
			delete insertDoctorSchedule.Data;
			return res.json(insertDoctorSchedule);
		}
		else {
			res.json(insertDoctorSchedule);
		}
	}
	catch (err) {
		console.log("Error saving schedule:(Controller) ", err);
		res.json({
			Error: true,
			Message: 'Error Saving Doctor Schedule.'
		});
	}
};