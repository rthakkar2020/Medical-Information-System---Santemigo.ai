//MODELS
const doctorModel = require('../models/doctor.model');
const appointmentModel = require('../models/appointment.model');
const patientModel = require('../models/patient.model');

//MIDDLEWARES
const authMiddleware = require('../middleware/auth');

// GET ALL APPOINTMENTS OF SPECIFIC PATIENT/DOCTOR
module.exports.getAppointments = async function (req, res) {
	let getAppointments;
	try {
		getAppointments = await appointmentModel.getAppointmentsById(req.user._id);
	}
	catch (e) {
		console.log("Error: ", e);
	}
	if (getAppointments) {
		let length = Object.keys(getAppointments.Data).length;

		if (length === 0) {
			res.json({
				Error: true,
				Message: 'No Appointments Found.',
			});
		}
		else {
			res.json({
				Error: false,
				Message: 'Appointments for Specific Patient/Dotor',
				Data: getAppointments.Data
			});
		}
	}
};