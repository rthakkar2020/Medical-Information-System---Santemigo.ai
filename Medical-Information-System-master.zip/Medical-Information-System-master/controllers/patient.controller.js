const winston = require('winston');
const chalk = require("chalk");
const moment = require('moment');

//MODELS
const patientModel = require('../models/patient.model');
const appointmentModel = require('../models/appointment.model');
const specialtieModel = require('../models/specialty.model');
const doctorModel = require('../models/doctor.model');
const doctorScheduleModel = require('../models/doctorSchedule.model');

//MIDDLEWARES
const authMiddleware = require('../middleware/auth');

// CREATE PATIENT
module.exports.insertPatient = async function (req, res) {
	let patient;
	try {
		patient = await patientModel.insertPatientData(req.body);
	}
	catch (e) {
		console.log("Error: ", e);
	}
	console.log('Patient Controller/ Insert Patient: ', patient);
	res.json(patient);
}

// PATIENT LOGIN
exports.login = async function (req, res) {
	let getPatient;
	try {
		getPatient = await patientModel.findByPatientCredentials({
			email: req.body.email,
			password: req.body.password
		});
	}
	catch (e) {
		console.log("Error: ", e);
	}
	if (getPatient) {
		// console.log('Patient Controller/ Login: ', getPatient);
		let length = Object.keys(getPatient.Data).length;
		if (length == 0) {
			return res.json({
				Error: true,
				Message: "Wrong email and/or password.",
			})
		}
		else {
			try {
				token = await authMiddleware.generateAuthToken(
					JSON.parse(JSON.stringify(getPatient))
				);
			}
			catch (e) {
				console.log("Token Error: ", e);
			}
			res.json({
				Error: false,
				Message: "Login successful",
				Data: {
					token: token
				}
			});
		}
	}
}

// BOOK AN APPOINTMENT
module.exports.bookAppointment = async function (req, res) {
	req.body.patient = req.user._id;
	let bookAppointment;
	try {
		bookAppointment = await appointmentModel.bookAppointmentData(req.body);
	}
	catch (e) {
		console.log("Error Booking Appointment: ", e);
	}
	res.json(bookAppointment);
};

// PATIENT LOGOUT
exports.logout = function (req, res) {
	req.session.destroy();
	res.json({
		Error: false,
		Message: "Logout Successfully",
	})
};

// GET ALL APPOINTMENTS OF SPECIFIC PATIENT
module.exports.getAppointments = async function (req, res) {
	let getAppointments = await appointmentModel.getAppointmentsByPatientId(req.params.patientId);

	let length = Object.keys(getAppointments.Data).length;

	if (length === 0) {
		res.json({
			Error: true,
			Message: 'No Appointments Found.',
		});
	}
	else {
		res.json({
			Error: false,
			Message: 'Appointments for Specific Patient.',
			Data: getAppointments.Data
		});
	}
};

// CANCEL AN APPOINTMENT
module.exports.cancelAppointment = async function (req, res) {
	let cancelAppointment = await appointmentModel.cancelAppointmentData(req.params.appointmentId, req.user._id);

	console.log('Patient Controller: / Appointments/ Cancel ', cancelAppointment);

	let length = Object.keys(cancelAppointment.Data).length;
	if (length === 0) {
		delete cancelAppointment.Data;
		return res.json(cancelAppointment);
	}
	res.json(cancelAppointment);
};

// GET ALL THE SPECIALTIES
module.exports.getAllSpecialties = async function (req, res) {
	let specialties = await specialtieModel.getAllSpecialtiesData();

	let length = Object.keys(specialties.Data).length;

	if (length == 0) {
		return res.json({
			Error: true,
			Message: 'No Specialties Found.'
		});
	}
	res.json(specialties);
};

// GET ALL DOCTORS BY SPECIALTY
module.exports.getAllDoctorsBySpecialty = async function (req, res) {
	let findPatient = await patientModel.findPatientById(req.user._id);
	console.log("Here Patient Controller: ", findPatient);

	let findPatientLen = Object.keys(findPatient.Data).length;

	if (findPatientLen != 0) {
		let getDoctors = await doctorModel.getAllDoctorsBySpecialtyData(req.params.specialtyId);

		let length = Object.keys(getDoctors.Data).length;

		if (length == 0) {
			return res.json({
				Error: true,
				Message: 'No Doctors Found.'
			});
		}
		res.json(getDoctors);
	}
	else {
		delete findPatient.Data;
		res.json(findPatient);
	}
};

// GET AVAILABLE DAYS OF SPECIFIC DOCTOR
module.exports.getAvailableDays = async function (req, res) {
	try {
		let getAvailableDays = await doctorScheduleModel.getAvailableDaysData(req.params.doctorId);

		let length = Object.keys(getAvailableDays.Data).length;

		if (length == 0) {
			return res.json(getAvailableDays);
		}
		else {
			getAvailableDays.Data = getAvailableDays.Data.availableDays;
			res.json(getAvailableDays);
		}
	}
	catch (e) {
		console.log("No Schedule Found Error: ", e);
		res.json({
			Error: true,
			Message: 'No Schedule Found.'
		});
	}
};

// GET AVAILABLE SLOTS
module.exports.getAvailableSlots = async function (req, res) {
	let availableSlotsDS;
	console.log("Day:(Query Params) ", req.query.day);
	console.log(typeof req.query.day);
	try {
		availableSlotsDS = await doctorScheduleModel.getAvailableSlotsData(req.params.doctorId);
	}
	catch (err) {
		res.json({
			Error: true,
			Message: 'Error Finding Available Slots.'
		});
	}
	if (availableSlotsDS) {
		console.log(availableSlotsDS);
		if (Object.keys(availableSlotsDS.Data).length == 0) {
			res.json({
				Error: true,
				Message: 'No Schedule Found.'
			});
		}
		else {
			// res.json(availableSlotsDS);
			let appointments;
			try {
				appointments = await appointmentModel.getAppointments(req.params.doctorId, req.query.day);
			}
			catch (e) {
				res.json({
					Error: true,
					Message: 'Error Finding Appointments.'
				});
			}
			if (appointments) {
				console.log("Appointments: ", appointments);

				if (Object.keys(appointments).length == 2) {
					return res.json({
						Error: true,
						Message: 'Database Error'
					});
				}

				// console.log("Available Slots: ", availableSlotsDS);
				var date = req.query.day;
				// var time = "18:00";

				let dateString = moment(date).format('YYYY-MM-DD');
				console.log(dateString);

				// var timeAndDate = moment(dateString + ' ' + time);
				// console.log(timeAndDate.format());
				let allSlots = [];
				for (var i = 0; i < availableSlotsDS.Data.timeStops.length; i++) {
					allSlots[i] = moment(dateString + ' ' + availableSlotsDS.Data.timeStops[i]).format();
				}
				console.log("All Slots: ", allSlots);

				if (Object.keys(appointments.Data).length == 0) {

					let freeSlots = [];

					for (var i = 0; i < allSlots.length; i++) {
						if (i < allSlots.length - 1) {
							let freeSlot = {};
							freeSlot.startTime = allSlots[i];
							freeSlot.endTime = allSlots[i + 1];

							let temp = moment(freeSlot.startTime).add(availableSlotsDS.Data.slotSpan, 'minutes');
							if (moment(freeSlot.endTime).isSame(temp)) {
								freeSlots.push(freeSlot);
							}
						}
					}
					console.log("Free Slots: ", freeSlots);

					return res.json({
						Error: false,
						Message: 'Doctor Free Slots.',
						Data: freeSlots
					});
					// delete appointments.Data;
					// return res.json(appointments);
				}
				else {

					// console.log("Appointments Here: ", appointments);
					let sTimesArray = [];
					for (var i = 0; i < appointments.Data.length; i++) {
						sTimesArray.push(moment(appointments.Data[i].startTime).format());
					}
					console.log("Stime Array: ", sTimesArray);

					// FILTER ARRAY
					let freeArray = [];
					freeArray = allSlots.filter(function (element) {
						return !sTimesArray.includes(element);
					});

					console.log(freeArray);

					let freeSlots = [];
					
					for (var i = 0; i < freeArray.length; i++) {
						if (i < freeArray.length - 1) {
							let freeSlot = {};
							freeSlot.startTime = freeArray[i];
							freeSlot.endTime = freeArray[i + 1];

							let temp = moment(freeSlot.startTime).add(availableSlotsDS.Data.slotSpan, 'minutes');
							if (moment(freeSlot.endTime).isSame(temp)) {
								freeSlots.push(freeSlot);
							}
						}
					}
					console.log("Free Slots: ", freeSlots);

					return res.json({
						Error: false,
						Message: 'List Of Free Slots.',
						Data: freeSlots
					});
				}
			}
			else {
				res.json({
					Error: true,
					Message: 'Error Finding Appointments.'
				});
			}
		}
	}
	else {
		res.json({
			Error: true,
			Message: 'No Schedule Found.'
		});
	}
}