process.env.NODE_ENV = process.env.NODE_ENV || 'development';

const express = require('express');
const path = require('path');
const logger = require('morgan');
const winston = require('winston');
const cookieParser = require('cookie-parser');
var expressSession = require('express-session');
// const cron = require('node-cron');
const chalk = require('chalk');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require('dotenv').config();

// HELPER
const mongoDb = require('./helpers/mongoDb');

// SERVICE


// CONTROLLERS

const app = express();

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(expressSession({
  secret: process.env.CYPHER_KEY,
  resave: true,
  saveUninitialized: true,
  cookie: {
    sameSite:false,
  }
}));

// app.use(function(req, res, next) {
//   req.io = chat.getSocket();
//   next();
// });

// ========================== DATABASE CONNECTION ==============================
const mongoURL = mongoDb.makeConnectionString();
mongoose.connect(mongoURL);
const db = mongoose.connection;

db.on('connecting', function() {
  winston.info(chalk.yellow('connecting to MongoDB...'));
});

db.on('error', function(error) {
  winston.error(chalk.red('Error in MongoDb connection: ' + error));
  mongoose.disconnect();
});

db.on('connected', function() {
  winston.info(chalk.green('158.69.205.234:27017 => connected'));
});

db.once('open', function() {
  winston.info(chalk.green('MongoDB connection opened!'));
});

db.on('reconnected', function () {
  winston.info(chalk.blue('MongoDB reconnected!'));
});

app.use(function(req, res, next) {
  req.db = db;
  next();
});

mongoose.Promise = global.Promise;
// =============================================================================

require('./routes/index')(app);


// CATCH 404 AND FORWARD TO ERROR HANDLER
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// ERROR HANDLER
app.use(function(err, req, res, next) {
  // SET LOCALS, ONLY PROVIDING ERROR IN DEVELOPMENT
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.json({
    Error: true,
    message : res.locals.message,
  })
});

module.exports = app;