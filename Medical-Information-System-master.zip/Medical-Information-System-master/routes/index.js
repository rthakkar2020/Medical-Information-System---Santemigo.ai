const express = require('express');
const router = express.Router({mergeParams: true});

// middleware to use for all requests

module.exports = function(app) {
	router.use('/doctor', require('./doctor'));
	router.use('/patient', require('./patient'));
	app.use('/api/', router);
}
