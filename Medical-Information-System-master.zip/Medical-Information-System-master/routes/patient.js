const express = require('express');
const router = new express.Router();

//MIDDLEWARES
const authMiddleware = require('../middleware/auth');

//CONTROLLERS
const patientController = require('../controllers/patient.controller');
const commonController = require('../controllers/common.controller');

// CREATE NEW PATIENT(SIGNUP)
router.post('/signup', patientController.insertPatient);

// PATIENT LOGIN
router.post('/login', patientController.login);

// BOOK AN APPOINTMENT
router.post('/appointment', authMiddleware.validateAuthToken, patientController.bookAppointment);

// GET APPOINTMENTS FOR SPECIFIC PATIENT 
router.get('/appointment', authMiddleware.validateAuthToken, commonController.getAppointments);

// CANCEL AN APPOINTMENT
router.put('/appointment/:appointmentId', authMiddleware.validateAuthToken, patientController.cancelAppointment);

// STARTS: THE ROUTES HELPFUL FOR BOOKING APPOINTMENT

// GET ALL SPECIALTIES
router.get('/specialty', authMiddleware.validateAuthToken, patientController.getAllSpecialties);

// GET ALL THE DOCTORS BY SPECIALTY
router.get('/doctor/:specialtyId', authMiddleware.validateAuthToken, patientController.getAllDoctorsBySpecialty);

// GET AVAILABLE DAYS FOR SPECIFIC DOCTOR
router.get('/doctorSchedule/:doctorId', authMiddleware.validateAuthToken, patientController.getAvailableDays);

// GET AVAILABLE SLOTS
router.get('/appointment/doctorSchedule/:doctorId', authMiddleware.validateAuthToken, patientController.getAvailableSlots);

//ENDS: THE ROUTES HELPFUL FOR BOOKING APPOINTMENT

// PATIENT LOGOUT
router.get('/logout', patientController.logout);

module.exports = router;