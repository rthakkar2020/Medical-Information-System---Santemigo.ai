const express = require('express');
const router = new express.Router();

// MODELS
const Doctor = require('../models/doctor.model');

// MIDDLEWARES
const authMiddleware = require('../middleware/auth');

//CONTROLLERS
const doctorController = require('../controllers/doctor.controller');
const commonController = require('../controllers/common.controller');

// CREATE NEW DOCTOR(SIGNUP)
router.post('/signup', doctorController.insertDoctor);

// DOCTOR LOGIN
router.post('/login', doctorController.login);

// GET APPOINTMENTS FOR SPECIFIC DOCTOR 
router.get('/appointment', authMiddleware.validateAuthToken, commonController.getAppointments);

// DOCTOR LOGOUT
router.get('/logout', doctorController.logout);

// CANCEL OR CONFIRM APPOINTMENT
router.put('/appointment/:appointmentId', authMiddleware.validateAuthToken,  doctorController.cancelOrConfirmAppointment);

// ADD DOCTOR SCHEDULE
router.post('/doctorSchedule', authMiddleware.validateAuthToken, doctorController.insertDoctorSchedule);

module.exports = router;