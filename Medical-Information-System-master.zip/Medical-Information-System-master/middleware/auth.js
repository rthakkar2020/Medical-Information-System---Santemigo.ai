const winston = require('winston');
const chalk = require('chalk');
const jwt  = require('jsonwebtoken');

module.exports = {
	generateAuthToken: async function(userData) {
		return await jwt.sign(userData, process.env.CYPHER_KEY, {
			expiresIn: process.env.TOKEN_EXPIRATION
		})
	},

	validateAuthToken: async function (req, res, next) {
		const { authorization } = req.headers;
		new Promise( async (resolve, reject)=> {
			if (authorization && authorization != '') {
				jwt.verify(authorization, process.env.CYPHER_KEY, function(err, decoded) {
					if (err) {
						winston.error(chalk.red(err));
						resolve({
							status:401,
							message: `Session expired. Your account was
							logged into from another device. Login again to continue.`});
					} else {
						resolve({ status:200, user: decoded.Data});
					}
				});
			} else {
				resolve({status:400, message:'Authorization token must be required!'});
			}
		}).then(({status,message, user}) => {
			req['user'] = (status == 200) ? user : null;
			(status == 200) ? next() : res.json({status,message});
		});
	}
};
